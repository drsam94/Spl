
int square(int x) {
	return x * x;
}

int cube(int x) {
	return x * x * x;
}

int twice(int x) {
	return 2 * x;
}
